package progetto;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;

import progetto.Login.Lgn;

public class srFrm extends JFrame {		//frame di modifica nome utente

	private JPanel contentPane;
	private JTextField ldUsr;
	private JTextField nwUsr;
	
	public srFrm() {
		setTitle("Modifica Nome Utente");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(500, 250, 450, 185);
		contentPane = new JPanel();								//set delle propriet� del frame
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ldUsr = new JTextField();
		ldUsr.setBounds(29, 30, 169, 22);
		contentPane.add(ldUsr);						//set del campo contente il nome utente corrente
		ldUsr.setColumns(10);
		ldUsr.setEditable(false);
		ldUsr.setText(Lgn.getUsr());
		
		nwUsr = new JTextField();					//set del campo contente il nuovo username
		nwUsr.addMouseListener(new MouseAdapter() {		//attivatore per impostare testo del campo
			public void mouseClicked(MouseEvent arg0) {
				nwUsr.setText("");
			}
		});
		nwUsr.setText("Nuovo Username");
		nwUsr.setBounds(29, 79, 169, 22);
		contentPane.add(nwUsr);
		nwUsr.setColumns(10);
		
		JButton btcmb = new JButton("Cambia Username");
		btcmb.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {				//creazione bottone e attivatore per cambiare nome utente
				String us=nwUsr.getText();
				int r=JOptionPane.showConfirmDialog(null, "Cambio Nome","Vuoi davvero cambiare?",JOptionPane.YES_NO_OPTION);
				if(r==JOptionPane.YES_OPTION){
					Database conn= new Database();
						boolean ar=conn.inserisci("update Utenti set Username='"+us+"' where username= '" +Lgn.getUsr()+"'"); //aggiunta al DB dei dati modificati
						ResultSet rs=conn.estrai("select * form utenti where username= '"+Lgn.getUsr()+"';");			//estrazione dal DB il campo dell'utente selezionato
						try {
							Prc.ut.modifica(rs, rs.getRow());		//modifica dati utente nel contenitore
						} catch (SQLException e) {
							e.printStackTrace();
						}
						if (ar)Lgn.setUsr(us);
						else JOptionPane.showMessageDialog(null, "Qualcosa � andato storto riprovare");
					dispose();
				}
			}
		});
		btcmb.setBounds(256, 45, 137, 43);
		contentPane.add(btcmb);
	}
}
