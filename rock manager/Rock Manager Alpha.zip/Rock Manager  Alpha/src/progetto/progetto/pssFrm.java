package progetto;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JButton;

import progetto.Login.Lgn;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;

public class pssFrm extends JFrame {		//frame di modifica password

	private JPanel contentPane;
	private JPasswordField pssV;
	private JPasswordField pssN;
	private JPasswordField pssR;
	private JLabel vPss;
	private JLabel nPss;
	private JLabel rPss;
	private JLabel lErr;

	public pssFrm() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	//set delle impostazioni del frame e campi password e label
		setBounds(100, 100, 450, 263);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pssV = new JPasswordField();
		pssV.setBounds(215, 50, 166, 22);
		pssV.setEchoChar((char) 0);
		contentPane.add(pssV);
		
		pssN = new JPasswordField();
		pssN.setBounds(215, 85, 166, 22);
		pssN.setEchoChar((char) 0);
		contentPane.add(pssN);
		
		pssR = new JPasswordField();
		pssR.setBounds(215, 120, 166, 22);
		pssR.setEchoChar((char) 0);
		contentPane.add(pssR);
		
		vPss = new JLabel("Vecchia Password");
		vPss.setBounds(35, 53, 103, 16);
		contentPane.add(vPss);
		
		nPss = new JLabel("Nuova Password");
		nPss.setBounds(35, 88, 103, 16);
		contentPane.add(nPss);
		
		rPss = new JLabel("Ripeti Password");
		rPss.setBounds(35, 123, 103, 16);
		contentPane.add(rPss);
		
		JButton bMod = new JButton("Modifica");
		bMod.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {		//metodo click bottone modifica
				String psV=pssV.getText();
				String psN=pssN.getText();
				String psR=pssR.getText();
				
				if(psV.equals(Lgn.getPsw())&(psN.equals(psR))){		//confronto la password vecchia con quella inserita all'accesso
					int u=JOptionPane.showConfirmDialog(null, "Cambio Password","Vuoi davvero cambiare?",JOptionPane.YES_NO_OPTION);
					if(u==JOptionPane.YES_OPTION){
						Database conn= new Database();		
							boolean ar=conn.inserisci("update Utenti set Password='"+psN+"' where username= '" +Lgn.getUsr()+"';");//update del campo password
							ResultSet rs=conn.estrai("select * form utenti where username= '"+Lgn.getUsr()+"';");
							try {
								Prc.ut.modifica(rs, rs.getRow());	//aggiornamento contenitore dati utente
							} catch (SQLException e) {
								e.printStackTrace();
							}
							if(ar)Lgn.setPsw(psN);
							else JOptionPane.showMessageDialog(null, "Errore imprevisto, riprovare.");
						dispose();
					}
				}
				else
					lErr.setVisible(true);
			}
		});
		bMod.setBounds(156, 178, 97, 25);
		contentPane.add(bMod);
		
		lErr = new JLabel("Campi Non Corrispondenti");		//label in caso di errore
		lErr.setVisible(false);
		lErr.setForeground(Color.RED);
		lErr.setBounds(121, 152, 179, 16);
		contentPane.add(lErr);
	}
}
