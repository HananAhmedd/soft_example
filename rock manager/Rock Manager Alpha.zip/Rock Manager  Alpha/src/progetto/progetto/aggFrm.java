package progetto;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

import progetto.Login.Lgn;

import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class aggFrm extends JFrame {

	private JPanel contentPane;
	public boolean f=false;
 
	public aggFrm(final JTextArea avvisi, final String sel, boolean dec, final JTable table, final int riga) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 546, 555);
		contentPane = new JPanel();
		contentPane.setBounds(new Rectangle(0, 0, 150, 0));			//imposto l'aspetto e il layout del fram
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		final JLabel lArr[]= new JLabel[table.getColumnCount()-1];
		final JTextField tArr[]= new JTextField[table.getColumnCount()-1];		//creo array di campi di testo e label per contenere e 
		for(int i=1; i<table.getColumnCount();i++){								//e modificare i dati del record scelto
			lArr[i-1]=new JLabel(table.getColumnName(i));						//riempio le label
			contentPane.add(lArr[i-1]);
			if(dec==true){
				Object cont=table.getModel().getValueAt(riga, i);
				tArr[i-1]=new JTextField(table.getColumnName(i));
				tArr[i-1].setText(cont.toString());								//riempio i campi di testo con i dati nel casi sia una modifica
				tArr[i-1].setEditable(false);
				contentPane.add(tArr[i-1]);
			}else{
				tArr[i-1]=new JTextField(table.getColumnName(i));
				tArr[i-1].setText("");											//testo vuoto nel caso di una creazione
				contentPane.add(tArr[i-1]);
			}
		}
		
		contentPane.setLayout(new GridLayout(0, 1, 10, 0));
		JLabel vuota= new JLabel("");
		contentPane.add(vuota);
		JButton agg = new JButton("Aggiungi");									//aggiungo bottone conferma e label
		contentPane.add(agg);
		agg.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				aggiungi(avvisi,table, tArr,sel);										//creo listener del mouse per salvare le info
				dispose();
			}
		});
		if(dec==true){
			agg.setVisible(false);
			final JButton agg1 =new JButton("Modifica");
			agg1.setVisible(true);
			contentPane.add(agg1);
			agg1.addMouseListener(new MouseAdapter(){						
				public void mouseClicked(MouseEvent e){							
					if(f==false){
						f=true;
						for(int i=0;i<table.getColumnCount()-1;i++){			//set del frame per la modifica
							setTitle("Modifica");
							tArr[i].setEditable(true);
						}													
						agg1.setText("Salva");
					}
					else{
						modifica(avvisi,table,tArr,riga,sel);							//richiamo funzione per modificare i dati immessi
						dispose();
					}
				}
			});
		}
		pack();
	}
	
	public void aggiungi(JTextArea avvisi,JTable table, JTextField[] campi,String tab){			//metodo per aggiornare la tabella, il DB e il contenitore dati
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		String riga[]= new String[table.getColumnCount()];			
		String s="insert into "+tab+" values (null,";							//preparo la stringa di update nel DB
		int l=table.getRowCount()+1;
		int q=0;
		riga[0]=String.valueOf(l);												
		for(int i=1; i<table.getColumnCount();i++){
			if(table.getColumnName(i).equalsIgnoreCase("Quantita")==true)
				q=Integer.parseInt(campi[i-1].getText());
			if(table.getColumnName(i).contains("Data")){
				s=s.concat("'"+convData(campi[i-1].getText())+"' ,");			//concatenazione stringa di update
				riga[i]=convData(campi[i-1].getText());							//copia dei dati nell'array per aggiornamento
			}else{
				s=s.concat("'"+campi[i-1].getText()+"',");
				riga[i]=campi[i-1].getText();
			}
		}
		s=s.substring(0,s.length()-1);
		s=s.concat(");");
		model.addRow(riga);							//aggiungo array al modello di tabella
		Database conn= new Database();
		if(conn.inserisci(s)==true){						//inserisco dati nel DB
			conn.inserisci("insert into logmod values (null,'"+Lgn.getUsr()+"','"+tab+"','"+(table.getRowCount())+"','Creazione',now());");//aggiorno log modifiche
			aggM(tab,""+table.getValueAt(table.getRowCount()-1,2),q);
			avvisi.setText("");
			Schprc.setAvvisi(avvisi,"materie_prime",200, true);	
			Schprc.setAvvisi(avvisi,"prodotti",20,false);//aggiorno il textpane con i dati sulle quantit� di materiali e prodotti
		}
		else JOptionPane.showMessageDialog(null,"Qualcosa nell'inserimento � andato male, riprovare.");
	}
	
	public void modifica(JTextArea avvisi,JTable table, JTextField campi[], int riga, String tab){		//metodo per modificare la tabella, il DB e il contenitore dati
		String s="update " +tab+ " set ";	//creazione stringa di update del DB
		int q=0;
		int q1=0;
		for(int i=1; i<table.getColumnCount();i++){
			if(table.getColumnName(i).equalsIgnoreCase("Quantita")==true){
				q=Integer.parseInt(campi[i-1].getText());
				q1=Integer.parseInt((String) table.getValueAt(riga, i));
			}
				
			s=s.concat(table.getColumnName(i)+" = '"+campi[i-1].getText()+"' ,");		//concatenazione stringa di update del DB
			table.getModel().setValueAt(campi[i-1].getText(), riga, i);
		}
		s=s.substring(0, s.length()-1);
		s=s.concat("where "+table.getColumnName(0)+" = '"+table.getValueAt(riga,0)+"' ;");
		Database conn= new Database();
		if(conn.inserisci(s)==true)	{				//update del DB
			conn.inserisci("insert into logmod values (null,'"+Lgn.getUsr()+"','"+tab+"','"+(riga+1)+"','Modifica',now());"); //aggiornamento del log modifiche
			if(tab.equalsIgnoreCase("ordini")||tab.equalsIgnoreCase("acquisti")||tab.equalsIgnoreCase("produzione"))
				modM(tab,""+table.getValueAt(riga,2),q,q1);
			avvisi.setText("");
			Schprc.setAvvisi(avvisi,"materie_prime",200, true);	
			Schprc.setAvvisi(avvisi,"prodotti",20,false);//aggiorno il textpane con i dati sulle quantit� di materiali e prodotti
		}
		else JOptionPane.showMessageDialog(null,"Qualcosa nell'inserimento � andato male, riprovare.");
	}
	public String convData(String vData){		//metodo di conversione del formato data
		String data="";
		SimpleDateFormat gma = new SimpleDateFormat("dd-mm-yy");
		SimpleDateFormat amg = new SimpleDateFormat("yyyy-mm-dd");
		Date dateIT;
		try{
		  dateIT = gma.parse(vData);		//copia stringa data in oggetto Date
		  data = amg.format(dateIT);	  	//conversione dell'oggetto nel formato data scelto
		}
		catch (ParseException e){
		  e.printStackTrace();
		}
		return data;
	}
	public void aggiornamento(String tab,String[] record){		//metodo di aggiornamento del contenitore dati
		switch(tab){
		case "acquisti":
			Prc.acq.aggiungi(record);					//a seconda della tabella selezionata aggiungo un elemento
			break;										//al contenitore corretto
		case "clienti":
			Prc.cli.aggiungi(record);
			break;
		case "fornitori":
			Prc.forn.aggiungi(record);
			break;
		case "materie_prime":
			Prc.matP.aggiungi(record);
			break;
		case "ordini":
			Prc.ord.aggiungi(record);
			break;
		case "prodotti":
			Prc.prod.aggiungi(record);
			break;
		case "produzione":
			Prc.prodZ.aggiungi(record);
			break;
		}
	}
	public void aggiornamento(String tab, String[] record,int riga){ 		//metodo di modifica del contenitore dati
		switch(tab){
		case "acquisti":
			Prc.acq.modifica(riga,record);
			break;
		case "clienti":												//a seconda della tabella selezionata modifico un elemento
			Prc.cli.modifica(riga,record);							//del contenitore corretto
			break;
		case "fornitori":
			Prc.forn.modifica(riga,record);
			break;
		case "materie_prime":
			Prc.matP.modifica(riga,record);
			break;
		case "ordini":
			Prc.ord.modifica(riga,record);
			break;
		case "prodotti":
			Prc.prod.modifica(riga,record);
			break;
		case "produzione":
			Prc.prodZ.modifica(riga,record);
			break;
		}
	}
	public void aggM(String tab, String ID, int nVal){			//metodo per aggiornare i dati di
		Database conn= new Database();							//materie prime e prodotti
		String corr=null;
		String corr2=null;
		JTable model = null;
		int ind=Integer.parseInt(ID);
		if(tab.equalsIgnoreCase("acquisti")){
			corr2="ID_MateriaPrima";
			corr="materie_prime";
			model=Schprc.mp;
		}														//scelgo la tabella da modificare e modifico variabili
		else if (tab.equalsIgnoreCase("ordini")){
			corr2="ID_Prodotto";
			corr="prodotti";
			nVal=-nVal;
			model=Schprc.pr;
		}
		else if(tab.equalsIgnoreCase("produzione")){
			corr2="ID_Prodotto";
			corr="prodotti";
			model=Schprc.pr;
		}
		ResultSet rs=conn.estrai("select Q_Disponibile from "+corr+" where "+corr2+" ="+ID+";");		//estraggo il record del prodotto/materia prima da modificare
		try {
			rs.first();
			conn.inserisci("update "+corr+" set Q_Disponibile="+(nVal+rs.getInt("Q_Disponibile"))+" where "+corr2+"= "+ID+"");	//aggiungo il valore
			model.setValueAt(nVal+rs.getInt("Q_Disponibile"),ind-1 , 3);			//modifico i dati della tabella interessata
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void modM(String tab, String ID, int nVal, int vVal){
		Database conn= new Database();
		String corr=null;
		String corr2=null;
		int diff=vVal-nVal;
		int ind=Integer.parseInt(ID);
		JTable model = null;
		if(tab.equalsIgnoreCase("acquisti")){
			corr2="ID_MateriaPrima";
			corr="materie_prime";					//scelgo la tabella interessata e modifico variabili
			model=Schprc.mp;
			diff=-diff;
		}
		else if (tab.equalsIgnoreCase("ordini")||tab.equalsIgnoreCase("produzione")){
			corr2="ID_Prodotto";
			corr="prodotti";
			model=Schprc.pr;
		}
		ResultSet rs=conn.estrai("select Q_Disponibile from "+corr+" where "+corr2+" ="+ID+";");	//estraggo il record del prodotto/materia prima da modificare
		try {
			rs.first();
			conn.inserisci("update "+corr+" set Q_Disponibile="+(diff+rs.getInt("Q_Disponibile"))+" where "+corr2+"= "+ID+"");//modifico il valore
			model.setValueAt(diff+rs.getInt("Q_Disponibile"), ind-1, 3);						//modifico i dati nella tabella
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		
	}
}