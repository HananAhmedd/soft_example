package progetto;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.miginfocom.swing.MigLayout;

import javax.swing.JButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextArea;
import javax.swing.JFormattedTextField;
import javax.swing.JPasswordField;

import java.awt.event.ItemListener;

import javax.swing.JCheckBox;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import java.awt.event.ItemEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Login extends JFrame {

	private JPanel contentPane;
	private JFormattedTextField txtUsername;
	private JPasswordField txtPassword;
	private JButton btnAccedi;
	public Lgn log= new Lgn();
	private JTextArea lgnfll;
	private JCheckBox MP;
	public Database conn;
	int i=0;

	public Login() {
		setTitle("Login!!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 227);
		contentPane = new JPanel();								//set dell'aspetto e layout del frame
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[][][grow][grow][][grow]", "[][][][][grow][grow][]"));
		txtUsername = new JFormattedTextField();
		txtUsername.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {			//metodo per azzerare testo al click
				txtUsername.setText("");
			}
		});
		txtUsername.setText("Username");						//set del campo di testo
		contentPane.add(txtUsername, "cell 3 1,growx");
		txtUsername.setColumns(10);								
		txtPassword = new JPasswordField();						//set del campo password
		txtPassword.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent arg0) {
				txtPassword.setText("");						//metodo per azzerare testo al click
			}
		});		
		txtPassword.setText("Password");
		contentPane.add(txtPassword, "cell 3 3,growx");
		txtPassword.setColumns(10);
		btnAccedi = new JButton("Accedi");						//set del bottone per l'accesso
		btnAccedi.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {
				conn= new Database();
				int trovato=0;
				ResultSet rs=null;								
				try {
					rs= conn.estrai("select * from Utenti");
					log.setUsr(txtUsername.getText());
					log.setPsw(txtPassword.getText());			//al click del bottone confronto i dati con quelli del DB
					while (rs.next()){
						if (Lgn.getUsr().equals(rs.getString("Username"))&& log.getPsw().equals(rs.getString("Password"))){
							trovato=1;
						}						
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if(trovato==1){
					boolean ar=conn.inserisci("insert into logacc values (null,"+"'"+Lgn.getUsr()+"',now());");		//aggiorno il log accessi
					if (ar){
						logAccessi();
						Schprc frame1= new Schprc();			//accesso alla schermata principale
						frame1.setVisible(true);
					}else JOptionPane.showMessageDialog(null, "Qualcosa � andato storto riprovare.");				
					dispose();
					}
				else 
					JOptionPane.showMessageDialog(null, "Login non riuscito");
					lgnfll.setText("Login Fallito. \nReinserire i dati.");		//caso di immissione  dati sbagliati
					txtPassword.setText("");
					txtUsername.setText("");
			}
		});
		MP = new JCheckBox("Scopri Password");		
		MP.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {		//metodo per mostrare la password
				if(MP.isSelected()){
					txtPassword.setEchoChar((char) 0);
				}
					else txtPassword.setEchoChar('�');
			}
		});
		contentPane.add(MP, "cell 4 3");	
		lgnfll = new JTextArea();				//set della label per il caso di errore
		lgnfll.setEditable(false);
		contentPane.add(lgnfll, "flowy,cell 1 4 4 1,grow");
		contentPane.add(btnAccedi, "cell 4 6");	
		lgnfll.setForeground(Color.RED);
	}
	
	public void logAccessi(){				//metodo per scrivere sul disco fisso il log degli accessi sotto formato XML
		Element accesso=null;
		Document doc=new Document (accesso);
		Element log= new Element("log");
		doc.setRootElement(log);
		try {
			ResultSet rs1= conn.estrai("select * from logacc");			//estraggo i dati del log
			while(rs1.next()){
				accesso= new Element("Accesso");						//setto i tag da aggiungere al file
				accesso.setAttribute(new Attribute("Numero",rs1.getString("Numero")));
				accesso.addContent(new Element ("Username").setText(rs1.getString("Username")));//aggiungo attributi al nodo
				accesso.addContent(new Element ("Data").setText(rs1.getString("Data")));
				i++;
				doc.getRootElement().addContent(accesso);				//aggiungo nodo
			}
			XMLOutputter out= new XMLOutputter();
			out.setFormat(Format.getPrettyFormat());					//scrivo il file XML
			out.output(doc, new FileWriter("C:\\logA.xml"));			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static class Lgn{			//oggetto contenente i dati dell'utente nella sessione corrente
		static String Usr;
		static String Psw;
		
		public static void setUsr(String user){	//metodo set Nome utente
			Usr=user;
		}
		public static void setPsw(String pass){	//metodo set password utente
			Psw=pass;
		}
		public static String getUsr(){			//metodo get Nome utente
			return Usr;
		}
		public static String getPsw(){			//metodo get password utente
			return Psw;
		}
	}
}