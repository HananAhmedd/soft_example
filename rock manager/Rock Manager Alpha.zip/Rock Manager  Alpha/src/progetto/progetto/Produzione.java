package progetto;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

public class Produzione {
	Vector<String[]> dati=null;			//vettore contenente i dati della tabella
	public Produzione(){
		Database conn=new Database();
		String[] record=null;
		try{
			ResultSet rs=conn.estrai("select * from produzione;");		//estraggo dal DB i dati 
			ResultSetMetaData rsmd=rs.getMetaData();					//ottengo i dati relativi alla tabella
			dati= new Vector<String[]>();								//istanzio il contentitore dei dati
			record=new String[rsmd.getColumnCount()];
			while(rs.next()){
				for(int i=0; i<rsmd.getColumnCount();i++){				//immetto i dati nell'array di stringhe
					record[i]=rs.getString(i+1);
				}
				dati.add(record);										//aggiungo il record al vettore
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	public void aggiungi(String[] record){								//aggiungo un elemento alla fine del vettore
		dati.add(record);
	}
	public void modifica(int riga, String[] record){					//modifico un elemento del vettore
		dati.setElementAt(record, riga);
	}
}
