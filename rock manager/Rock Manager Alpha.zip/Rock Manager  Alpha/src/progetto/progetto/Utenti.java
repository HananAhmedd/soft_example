package progetto;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

public class Utenti {
	Vector<String[]> dati=null;				//vettore contenente i dati della tabella
	public Utenti(){
		Database conn=new Database();
		String[] record=null;
		try{
			ResultSet rs=conn.estrai("select * from utenti;");		//estraggo dal DB i dati
			ResultSetMetaData rsmd=rs.getMetaData();				//ottengo i dati relativi alla tabella
			dati= new Vector<String[]>();							//istanzio il contentitore dei dati
			record=new String[rsmd.getColumnCount()];
			while(rs.next()){
				for(int i=0; i<rsmd.getColumnCount();i++){
					record[i]=rs.getString(i+1);					//immetto i dati nell'array di stringhe
				}
				dati.add(record);									//aggiungo il record al vettore
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	public void modifica(ResultSet campo, int riga){				//metodo per modificare il contenitore dei dati
		try {
			String[] record=new String[campo.getMetaData().getColumnCount()];		//inserisco i dati in un array di stringhe
			for(int i=0; i<campo.getMetaData().getColumnCount();i++){
				record[i]=campo.getString(i+1);
			}
			dati.setElementAt(record, riga);				//rimpiazzo i dati precedenti con quelli nuovi
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

