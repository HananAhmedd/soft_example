package progetto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import progetto.Database;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class vLog{

	public vLog(String cmp){
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		String data[][] = {};
		String col[] = {};
		DefaultTableModel model = new DefaultTableModel(data,col);		//set del frame
		panel.setLayout(null);
		JTable table = new JTable(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		JScrollPane sc=new JScrollPane(table);						//aggiunta tabella allo scrollpane
		sc.setBounds(0, 0, 552, 442);
		table.setEnabled(false);
		panel.add(sc);
		frame.getContentPane().add(panel);
		frame.setSize(570,489);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Database conn= new Database();

		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		try {
			rs=conn.estrai("select * from "+cmp);					//connessione al DB
			rsmd=rs.getMetaData();
			for(int i=0; i<rsmd.getColumnCount();i++){
				model.addColumn(rsmd.getColumnName(i+1));			//creazione colonne
			}
			while (rs.next()){				
				Object[] dt=new Object[rsmd.getColumnCount()];		//caricamento campi nel record
				for(int i=0; i<rsmd.getColumnCount();i++){
					dt[i]=rs.getString(i+1);
				}
				model.addRow(dt);									//aggiunta record alla tabella
			}
			conn.chiudi(rs);										//chiusura della connessione col DB
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}