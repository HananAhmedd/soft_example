 package progetto;
import progetto.Login;


public class Prc {
	public static Acquisti acq;
	public static Clienti cli;		//creazione oggetti di contentimento dati;
	public static Fornitori forn;
	public static MateriePrime matP;
	public static Prodotti prod;
	public static Produzione prodZ;
	public static Ordini ord;
	public static Utenti ut;
	
	public static void main(String[] args) {
			
		try {
			Login frame = new Login(); 				//avvio il frame di login
			frame.setVisible(true);
			acq=new Acquisti();						//istanzio gli oggetti;
			cli=new Clienti();
			forn=new Fornitori();
			matP=new MateriePrime();
			ord=new Ordini();
			prod=new Prodotti();
			prodZ=new Produzione();
			ut=new Utenti();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
