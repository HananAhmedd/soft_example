package progetto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class Database {	
	public ResultSet estrai(String richiesta){				//metodo per estrarre dati del DB
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();		//carico il driver per la connessione al DB
			String url = "jdbc:mysql://localhost:3306/progetto";
			conn = DriverManager.getConnection(url, "root", "");		//mi connetto al DB...cambiare utente e password se si esporta il DB su altro server
			st= conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs=st.executeQuery(richiesta);				//eseguo la query richiesta dalla stringa passata
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null,"Controlla la connessione a internet!");
			e.printStackTrace();
			}
		catch (ClassNotFoundException e){
			e.printStackTrace();
			}
		catch (IllegalAccessException e){
			e.printStackTrace();
			} 
		catch (InstantiationException e) {
			e.printStackTrace();
			}
				return rs;				//restituisco il risultato della query
	}
	public boolean inserisci(String comando){
		Connection conn=null;
		Statement st=null;
		int ris=0;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url = "jdbc:mysql://localhost:3306/progetto";
			conn = DriverManager.getConnection(url, "root", "");
			st= conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ris=st.executeUpdate(comando);
			st.close();
			conn.close();
		}
		catch (SQLException e){
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		if(ris==0){
			return false;
		}else
			return true;
	}
	public void chiudi(ResultSet rs){			//metodo per chiudere la connessione aperta estraendo i dati dal DB
		try {
			Statement st=rs.getStatement();		//ottengo lo statement
			rs.close();							//chiudo il resultset
			Connection cnn=st.getConnection();	//ottengo la connessione
			st.close();							//chiudo lo statement
			cnn.close();						//chiudo la connessione
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
