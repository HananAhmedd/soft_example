package progetto;

import javax.swing.ImageIcon;					//schermata principale
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTabbedPane;
public class Schprc extends JFrame {

	private JPanel contentPane;
	public static Modello A;
	public static JTable mp;
	public static JTable pr;
	final JTabbedPane tabbedPane;
	DefaultTableModel model;
	public JTextArea avvisi;

	public Schprc() {
		setResizable(false);
		setTitle("Rock Manager 0.53 Alpha");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		//set layout e impostazioni frame
		setBounds(100,100,1229,777);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		contentPane.setBackground(Color.LIGHT_GRAY);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Font mio= new Font("Tahoma", Font.BOLD, 20);
		
		avvisi= new JTextArea("");
		avvisi.setOpaque(false);			//set del textPane contente gli avvisi su materie prime e prodotti
		avvisi.setEditable(false);
		avvisi.setVisible(true);
		
		JButton modut = new JButton("Modifica Nome Utente");
		modut.addMouseListener(new MouseAdapter() {			//metodo click per attivare modifica username
			public void mouseClicked(MouseEvent arg0) {
				srFrm ut= new srFrm();				//creazione e istanziazione frame modifica username
				ut.setVisible(true);
			}
		});
		modut.setBounds(59, 57, 190, 25);
		contentPane.add(modut, "2, 4, center, bottom");
		JScrollPane sc1=new JScrollPane(avvisi, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		sc1.setLocation(800, 34);
		sc1.setSize(300, 120);
		contentPane.add(sc1);
		setAvvisi(avvisi,"materie_prime",200, true);	//aggiornamento del textPane avvisi
		setAvvisi(avvisi,"prodotti",20,false);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		JPanel acq=crea("acquisti");			//creazione pannelli da inserire nella tabella a scorrimento
		JPanel forn=crea("fornitori");
		JPanel clie=crea("clienti");
		JPanel matP=crea("materie_prime");
		JPanel ord=crea("ordini");
		JPanel prod=crea("prodotti");
		JPanel prod2=crea("produzione");
		
		tabbedPane.addTab("Fornitori", forn);
		tabbedPane.addTab("Acquisti", acq);			//aggiunta pannelli alla tabella
		tabbedPane.addTab("Materie_Prime", matP);
		tabbedPane.addTab("Produzione", prod2);
		tabbedPane.addTab("Prodotti", prod);
		tabbedPane.addTab("Ordini", ord);
		tabbedPane.addTab("Clienti", clie);
		tabbedPane.setBounds(12, 169, 1187, 560);
		tabbedPane.setVisible(true);
		
		JLabel lb=new JLabel("");
		lb.setLocation(793, 13);			//creazione label ai bordi del textpane avvisi
		lb.setSize(313, 148);
		lb.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 255), 3, true), "Avvisi", TitledBorder.LEADING, TitledBorder.TOP, mio, new Color(0, 0, 255)));
		lb.setVisible(true);
		contentPane.add(lb);
		contentPane.add(tabbedPane);
		
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent evt) {		//metodo per rilevare il cambiamento di tab nella tabella
			JTabbedPane pane = (JTabbedPane)evt.getSource();//e salvare la tabella corrente
				A.setSelTab(pane.getTitleAt(pane.getSelectedIndex()));
				}
			});
		JButton modPass = new JButton("Modifica Password");
		modPass.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {	//metodo per attivare il bottone per il cambio password
				pssFrm ps=new pssFrm();					//creazione e istanziazione frame modifica password
				ps.setVisible(true);
			}
		});
		modPass.setBounds(59, 105, 190, 25);
		contentPane.add(modPass, "2, 6, fill, top");
		
		JButton logacc = new JButton("Log Accessi");
		logacc.addMouseListener(new MouseAdapter() {		//metodo per attivare il bottone di visualizzazione log accessi
			public void mouseClicked(MouseEvent arg0) {
				vLog n= new vLog("logacc");					//creazione e istanziazione frame visualizzazione log accessi
			}
		});
		logacc.setBorder(null);
		logacc.setBounds(456, 55, 132, 25);
		contentPane.add(logacc, "4, 4, fill, bottom");
		
		JButton logmod = new JButton("Log Modifiche");
		logmod.addMouseListener(new MouseAdapter() {		//metodo per attivare il bottone di visualizzazione log modifica
			public void mouseClicked(MouseEvent arg0) {
				vLog n= new vLog("logmod");					//creazione e istanziazione frame visualizzazione log accessi
			}
		});
		
		JLabel lblUtente = new JLabel("");
		lblUtente.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 255), 3, true), "Utente", TitledBorder.LEADING, TitledBorder.TOP, mio, new Color(0, 0, 255)));
		lblUtente.setForeground(Color.BLACK);
		lblUtente.setToolTipText("");
		lblUtente.setVerticalAlignment(SwingConstants.TOP);
		lblUtente.setBounds(45, 28, 219, 128);
		contentPane.add(lblUtente);							//set di varie label di contorno ai bottoni
		logmod.setBounds(456, 103, 132, 25);
		contentPane.add(logmod, "4, 6, fill, top");
		
		JLabel lblLog = new JLabel("");
		lblLog.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 255), 3, true), "Log", TitledBorder.LEADING, TitledBorder.TOP, mio, new Color(0, 0, 255)));
		lblLog.setVerticalAlignment(SwingConstants.TOP);
		lblLog.setBounds(442, 26, 161, 128);
		contentPane.add(lblLog);
		
		JLabel lbl = new JLabel(new ImageIcon(Schprc.class.getResource("img/sfondo.jpg")));
		getContentPane().add(lbl);							//set dello sfondo della schermata			
		lbl.setBounds(0, 0, 1223, 742);
		contentPane.add(lbl);	
	}
	
	public static void setAvvisi(JTextArea avvisi, String sogg, int q, boolean s){		//metodo per settare il testo del textpane avvisi
		Database conn= new Database();
		ResultSet rs=conn.estrai("select Nome from "+sogg+" where Q_Disponibile <"+q);	//estraggo i dati dal DB
		try {
			if(rs.next()==false){
				avvisi.append("\n     Nessun avviso riguardante "+sogg+"\n");				//verifico se sono presenti dati in caso negativo imposto stringa
			}
			rs.beforeFirst();
			while(rs.next()){
				if(s){
					avvisi.append("     Hai meno di "+q+"q di "+rs.getString("Nome")+"\n");	//aggiungo la stringa contente i dati della materia prima al textpane
					}
				else{
					avvisi.append("     Hai meno di "+q+" pezzi di "+rs.getString("Nome")+"\n");
				}
			}
			avvisi.repaint();
			conn.chiudi(rs);		//chiudo la connessione col DB
		}	
		 catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	public JPanel crea(String cmp){		//metodo che crea la tabella da inserire
		String data[][] = {};
		String col[] = {};				//set di colonne e righe predefinite
		model = new DefaultTableModel(data,col);
		final JTable table = new JTable(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		JScrollPane sc=new JScrollPane(table);		//aggiungo la tabella ad uno scrollpane
		sc.setBounds(12, 5, 1127, 512);
		table.setEnabled(false);
		A= new Modello();					//creo e istanzio un modello di tabella e lo aggiungo al pannello
		JPanel p= new JPanel();
		p.setLayout(null);
		JButton bott = new JButton("");
		URL url=this.getClass().getResource("img/images.jpg");
		bott.setIcon(new ImageIcon(url));
		bott.addMouseListener(new MouseAdapter() {		//aggiungo il bottone per aggiungere un nuovo record
			public void mouseClicked(MouseEvent arg0) {		//set dell'event mouse per attivarlo
				A.setMod(table);	
				aggFrm f=new aggFrm(avvisi,A.getSelTab(),false, A.getMod(),0);		//richiamo del frame per aggiungere dati
				f.setVisible(true);
				f.setTitle("Aggiungi "+A.getSelTab());
			}
		});
		bott.setBounds(1146, 33, 36, 35);
		p.add(bott);
		p.add(sc);
		table.addMouseListener(new MouseAdapter(){		//aggiungo evento per rilevare click sulle righe della tabella
			public void mouseClicked(MouseEvent me){
				if (me.getClickCount() == 2) {			
					JTable mi= (JTable)me.getSource();
					int row = mi.rowAtPoint(me.getPoint());
					A.setMod(table);
					aggFrm f=new aggFrm(avvisi,A.getSelTab(),true, A.getMod(),row);	//richiamo il frame per la modifica dei dati
					f.setVisible(true);
					f.setTitle("Visualizza");
				}
			}
		});
		riempi(model, cmp);			//richiamo il metodo per riempire la tabella	
		if(cmp.equals("materie_prime"))
			mp=table;
		if(cmp.equals("prodotti"))
			pr=table;
		return p;
	}
	public void riempi(DefaultTableModel model, String cmp){	//metodo creato per riempire le tabelle
		Database conn= new Database();
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		try {
			rs=conn.estrai("select * from "+cmp);			//estraggo i dati desiderati dal DB
			rsmd=rs.getMetaData();							//ottengo le specifiche della tabella
			for(int i=0; i<rsmd.getColumnCount();i++){
				model.addColumn(rsmd.getColumnName(i+1));	//set nome e numero colonne
			}
			while (rs.next()){
				Object[] dt=new Object[rsmd.getColumnCount()];		//creazione e campi
				for(int i=0; i<rsmd.getColumnCount();i++){
					dt[i]=rs.getString(i+1);
				}
				model.addRow(dt);								//aggiunta record alla tabella
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public class Modello{			//classe contenente i dati del modello tabella usato
		String selTab="Fornitori";
		JTable modSel;
		
		public void setSelTab(String sel){
			this.selTab=sel;		
		}
		public String getSelTab(){
			return this.selTab;
		}	
		public void setMod(JTable table){
			this.modSel=table;
		}
		public JTable getMod(){
			return this.modSel;
		}
	}
}