<!--EFFETTUO EVENTUALI MODIFICHE ALLE INFORMAZIONI RIGUARDANTI IL CITTADINO-->
<?php
    //SE LA SESSIONE NON E' ATTIVA LA RIATTIVO PER PRELEVARE DATI
    if(session_status()==PHP_SESSION_DISABLED||session_status()==PHP_SESSION_NONE)session_start();
    include 'ConnessioneDB.php';
    $newpassword=$_POST["password"];
    $confpassword=$_POST["conf_password"];
    if($newpassword!=$confpassword){
        include 'Modifica.php';
        echo 'Le passrword non corrispondono, si prega di riprovare.';
    }else{
        $newresidenza=$_POST["residenza"];
        $newncivico=$_POST["civico"];
        $newcittà=$_POST["città"];
        $newcap=$_POST["cap"];
        $newtelefono=$_POST["telefono"];
        $newtelefono=$_POST["telefono"];
        $newusername=$_POST["username"];
        $newemail=$_POST["email"];
        mysql_select_db($dbname1);
        $cittadino=mysql_query("SELECT nome FROM cittadino WHERE username='".$_SESSION["user"]."'");
        $citizen=mysql_fetch_array($cittadino);
        $querymodifica="UPDATE cittadino SET residenza='$newresidenza',n_civico='$newncivico',città_res='$newcittà',cap='$newcap',"
                . "username='$newusername',psw='$newpassword',telefono='$newtelefono',email='$newemail' "
                . "WHERE nome='".$citizen["nome"]."'";
        if(mysql_query($querymodifica)){
            $_SESSION["user"]=$newusername;
            include 'Login.php';
            echo 'Modifiche effettuate con successo';
        }else{
            include 'Login.php';
            echo 'Non è stato possibile effettuare le modifiche, si prega di riprovare più tardi';
        }
        
    }

