<!--PER OVVI MOTIVI, TUTTE LE FUNZIONI ALL'INTERNO DI QUESTO SITO SIMULERANNO L'ITERAZIONE TRA COMUNE ED UTENZA.
QUINDI TUTTE LE AZIONI CHE, ALTRIMENTI, RICHIEDEREBBERO TEMPI DI ATTESA NON DEFINITI POICHE' "UMANI"
VERRANNO ESEGUITE PER DARE UN'ESEMPIO DI COME IL SISTEMA INTERAGISCE CON GLI ATTORI E LE PROPRIE COMPONENTI-->
<html>
    <?php require 'intestazione.html'?>
    <body>
        <form action='VerificaDati.php' method='post'>
            <label>Username </label><input type="text" name="user">
            <label>Password </label><input type="password" name="psw"><td 20>
            <input type="submit" name="Login" value="Login">
        </form>
        <form action="Registrazione.php">
            <input type="submit" name="Registrazione" value="Registrati">
        </form>
    </body>
</html>