<?php 
    require 'intestazione.html';
    include 'ConnessioneDB.php';
    function stampa_data($i, $n){
        while($i<=$n){
            echo "<option value=$i>$i</option>\n";
            $i=$i+1;
        }
    }
?>
<form action="InserisciDati.php" method="post">
    <label>Nome: </label><input type="text" name="nome">
    <label>Cognome: </label><input type="text" name="cognome"><br><br><br>
    <label>Data di nascita: </label><select name="giorno">
        <?php
            stampa_data(1,31)
        ?>
    </select><select name="mese">
        <?php
            stampa_data(1,12)
        ?>
    </select><select name="anno">
        <?php
            stampa_data(date("Y")-100,date("Y"))
        ?>
    </select><br>
    <label>Luogo di nascita: </label><input type="text" name="città">
    <label>Provincia:</label><select name="provincia_nasc"> 
        <?php
            $query="SELECT * FROM città ORDER BY nome_prov";
            $ris=mysql_db_query($dbname2,$query);
            while($stamp2=mysql_fetch_array($ris)){
                $nome_prov=$stamp2["nome_prov"];
                    echo "<option value=$nome_prov>$nome_prov</option>\n";
                }
        ?> 
    </select><br>
    <label>Codice Fiscale: </label><input type="text" name="cod_fiscale"><br><br><br>
    <label>Residente in via: </label><input type="text" name="residenza">
    <label>N. civico: </label><input type="text" name="n_civico"><br>
    <label>Città: </label><input type="text" name="città_res">
    <label>Provincia: </label><input type="text" name="provincia" value="ME" disabled>
    <label>CAP: </label><input type="text" name="cap"><br>
    <label>Telefono: </label><input type="text" name="telefono"><br><br><br>
    <label>Username: </label><input type="text" name="username">
    <label>Password: </label><input type="password" name="psw"><br>
    <label>Email: </label><input type="text" name="email"><br><br>
    <label>Acconsento al trattamento dei miei dati personali.</label><input type="checkbox" name="privacy"><br>
    <input type="checkbox" name="terminiuso" value="si"><label> Ho letto e accetto i Termini d'uso del servizio: </label>
    <fieldset style="overflow: auto; height: 150px; width: 500px">
        <?php
            include "Termini d'uso.html";
        ?>
    </fieldset>
    <input type="submit" name="registrazione" value="Registrati">
    <?php mysql_close()?>
</form>