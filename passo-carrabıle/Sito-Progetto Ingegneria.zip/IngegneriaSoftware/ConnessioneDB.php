<?php
$dbhost="127.0.0.1";
$dbname1="prog_ingegneria";
$dbname2="località";
$dbuser="root";
$dbpsw="danilo";
$conn= mysql_connect($dbhost, $dbuser, $dbpsw)
        or die("Connessione col server temporaneamente non disponibile!");
?>
