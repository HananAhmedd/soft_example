<br>
<div>
    <form action="Login.php">
    <button type="submit">Home</button>
</form>
<form action="Logout.php">
    <button type="submit">LogOut</button>
</form>
</div>

