<?php include'Intestazione.html'; include'ConnessioneDB.php';?>
*Si prega di NON modificare le informazioni che non dovranno essere modificate<br>
Modifica dati personali:<br><br>
<!--L'UTENTE E' TENUTO AD INDICARE QUALI CAMPI SONO CAMBIATI, AD ESEMPIO IN SEGUITO AD UN TRASFERIMENTO DI RESIDENZA,
AI FINI DELLA CORRETTA REPERIBILITA' DA PARTE DEL COMUNE-->
<form action="InserisciModifiche.php" method="post">
    <?php
        session_start();
        $select="SELECT * FROM cittadino WHERE username='".$_SESSION["user"]."'";
        mysql_select_db($dbname1);
        $fetch=mysql_fetch_array(mysql_query($select));
            echo"<label>NOME: </label><input type='text' name='nome' value='".$fetch["nome"]."' disabled>";
            echo"<label>COGNOME: </label><input type='text' name='cognome' value='".$fetch["cognome"]."' disabled><br>";
            echo"<label>DATA DI NASCITA: </label><input type='text' name='data_nascita' value='".$fetch["data_nascita"]."' disabled>";
            echo"<label>LUOGO: </label><input type='text' name='luogo' value='".$fetch["luogo_nascita"]."' disabled>";
            echo"<label>PROVINCIA: </label><input type='text' name='provincia_nasc' value='".$fetch["provincia_nasc"]."' disabled><br>";
            echo"<label>CODICE FISCALE: </label><input type='text' name='codice_fiscale' value='".$fetch["cod_fiscale"]."' disabled><br><br>";
            echo"<label>RESIDENTE IN: </label><input type='text' name='residenza' value='".$fetch["residenza"]."'>";
            echo"<label>N.: </label><input type='text' name='civico' value='".$fetch["n_civico"]."'><br>";
            echo"<label>CITTA': </label><input type='text' name='città' value='".$fetch["città_res"]."'>";
            echo"<label>PROVINCIA: </label><input type='text' name='provincia' value='".$fetch["provincia"]."' disabled>";
            echo"<label>CAP: </label><input type='text' name='cap' value='".$fetch["cap"]."'><br>";
            echo"<label>TELEFONO: </label><input type='text' name='telefono' value='".$fetch["telefono"]."'><br><br>";
            echo"<label>USERNAME: </label><input type='text' name='username' value='".$fetch["username"]."'><br>";
            echo"<label>PASSWORD: </label><input type='text' name='password' value='".$fetch["psw"]."'>";
            echo"<label>CONFERMA PASSWORD: </label><input type='text' name='conf_password' value='".$fetch["psw"]."'><br>";
            echo"<label>EMAIL: </label><input type='text' name='email' value='".$fetch["email"]."'><br><br>";
            mysql_close();
    ?>
    <input type="submit" name="modifica" value="Modifica dati">
</form><br>
<?php include 'Tasto Home.php';