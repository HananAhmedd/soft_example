<?php 
    require 'intestazione.html'; 
    include 'ConnessioneDB.php'
?>
Pannello di controllo utente. Benvenuto
        <?php
//CONTROLLO SEMPRE SE LA SESSIONE E' PRESENTE POICHE' DA UN CAMBIO DI PAGINA ALL'ALTRO POTREBBE "SCADERE", GENERANDO
//UN ERRORE DURANTE LA STAMPA A VIDEO DELLE CREDENZIALI (NOME, COGNOME) DELL'UTENTE CHE HA ESEGUITO L'ACCESSO
            if(session_status()==PHP_SESSION_NONE){
                session_start();   
            }
            $user=$_SESSION["user"];
            $stp_cred= "SELECT nome, cognome FROM cittadino WHERE username='$user'";
            mysql_select_db($dbname1);
            $ris=mysql_fetch_array(mysql_query($stp_cred));
            echo strtoupper("  ".$ris["cognome"]." ".$ris["nome"]);
        ?>
    <br><br>
    <form action="Modifica.php">
        <button type="submit">Modifica dati</button><br>
    </form>
    <form action="Nuovo Passo.php">
        <button type="submit">Richiedi nuovo passo</button><br>
    </form><br>
<!--STAMPO A VIDEO I CARTELLI FATTI INSTALLARE DAL CITTADINO, PONENDO LA POSSIBILITA'
DI RIMUOVERLI O PAGARNE LA CAUZIONE-->
<form action="Invio richiesta.php" method="post">
    Cartelli, attualmente, intestati a lei:<br>
    <?php
        $nome=$ris["nome"];
        $mostra="SELECT passo_n,località_passo,n_civico,categoria,validità FROM passi_carrai"
                . " WHERE proprietario=(SELECT username FROM cittadino WHERE nome='$nome')";
        $ris=mysql_query($mostra);
        while($passi=mysql_fetch_array($ris)){
            echo "<label>Passo n: <input type='text' name='n_passo' value='".$passi['passo_n']."' disabled>"
                 ."- Località: <input type='text' name='località' value='".$passi['località_passo']."' disabled>"
                 ."- N: <input type='text' name='civico' value='".$passi['n_civico']."' disabled>"
                 ."- Categoria: <input type='text' name='categoria' value='".$passi['categoria']."' disabled>"
                 ."- Valido fino al: <input type='text' name='validità' value='".$passi['validità']."' disabled></label>"
                 ."<input type=radio name='passi' value='".$passi['passo_n']."'><br>"; 
        }
        mysql_close();
    ?>
    <br><br>
    <button type="submit" name="tasto" value="rimuovi">Richiedi rimozione passo</button>
    <br>
    <button type="submit" name="tasto" value="paga">Effettua pagamento annuale</button>
    <br><br>
</form>
    <form action="Logout.php">
        <button type="submit" value="Logout">Logout</button>
    </form>

        