<!--INSERISCO I DATI PER LA REGISTRAZIONE NEL DATABASE-->
<?php
    include 'ConnessioneDB.php';
    $nome=$_POST["nome"];
    $cognome=$_POST["cognome"];
    $giorno=$_POST["giorno"];
    $mese=$_POST["mese"];
    $anno=$_POST["anno"];
    $data_nascita="$giorno/$mese/$anno";
    $luogo_nascita=$_POST["città"];
    $provincia=$_POST["provincia_nasc"];
    $cod_fisc=$_POST["cod_fiscale"];
    $residenza=$_POST["residenza"];
    $civico=$_POST["n_civico"];
    $città_res=$_POST["città_res"];
    $cap=$_POST["cap"];
    $tel=$_POST["telefono"];
    $user=$_POST["username"];
    $psw=$_POST["psw"];
    $mail=$_POST["email"];
    $check=isset($_POST["terminiuso"]) ? $_POST["terminiuso"]:"no";
    if(isset($_POST["privacy"])){
        $privacy="true";
    } else {
        $privacy="false";    
    }
    $insert="INSERT INTO cittadino(nome,cognome,data_nascita,luogo_nascita,provincia_nasc,cod_fiscale,"
            . "residenza,n_civico,città_res,provincia,cap,username,psw,telefono,email,privacy) "
            . "VALUES ('$nome','$cognome','$data_nascita','$luogo_nascita','$provincia','$cod_fisc',"
            . "'$residenza','$civico','$città_res','ME','$cap','$user','$psw','$tel','$mail',$privacy)";
    mysql_select_db($dbname1);
    if($check=="no"||strlen($cod_fisc)<16||strlen($cod_fisc)>16){
        include 'Registrazione.php';
        if($check=="no"){
            echo "Termini d'uso non accettati";
        }
        if(strlen($cod_fisc)<16||strlen($cod_fisc)>16){
            echo "Lunghezza del codice fiscale non corretta, si prega di controllare e riprovare";
        }
    } else {
        include 'index.php';
        if (mysql_query($insert)) {    
            echo "Registrazione effettuata con successo";
        } else {
            echo "Errore durante la registrazione, si prega di riprovare più tardi.";
        }
    }
    mysql_close();