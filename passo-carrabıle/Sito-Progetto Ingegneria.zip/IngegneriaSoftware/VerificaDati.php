<!--VERIFICO DI DATI DI ACCESSO, SOLO IN CASO DI RISCONTRO POSITIVO L'UTENTE PIO' ACCEDERE-->
<?php
    session_start();
    include 'ConnessioneDB.php';
    $test=0;
    $user=$_SESSION["user"]=$_POST['user'];
    $psw=$_SESSION["psw"]=$_POST['psw'];
    $verify="Select username,psw FROM cittadino";
    mysql_select_db($dbname1);
    $is=mysql_query($verify);
    while($fetch=mysql_fetch_array($is)){ 
        if($fetch["username"]==$user&&$fetch["psw"]==$psw){
            include 'Login.php';
            $test=1;
        }       
    }
    if($test==0){
        include 'index.php';
        echo 'Dati inseriti non corretti, riprova!';
    }

