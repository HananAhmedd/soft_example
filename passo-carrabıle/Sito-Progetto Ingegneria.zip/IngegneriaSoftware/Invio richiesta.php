<!--GESTISCO LE 3 POSSIBILI RICHIESTE DIRETTAMENTE DA QUI
AVENDO BISOGNO DEI MEDESIMI DATI COSì DA EVITARE DI "TRASPORTARLI" PER PIù PAGINE-->
<?php include 'Intestazione.html';include 'ConnessioneDB.php'?>
<br><br>
<?php
    mysql_select_db($dbname1);
    if($_POST["tasto"]=='no'){
        include 'Login.php';
        echo 'Non è stato selezionato alcun cartello';
    }else{
//IN BASE ALLA SCELTA EFFETTUATA, DESIGNO LA VARIABILE "$_POST["tasto"]" AL CASO COMPETENTE
        session_start();
        if($_POST["tasto"]=="rimuovi"){
            $_SESSION["test"]=2;  
        }else if($_POST["tasto"]=='paga'){
            $_SESSION["test"]=3;
        }else{
            $_SESSION["test"]=1;
        }        
        switch($_SESSION["test"]){
//EFFETTUO L'AGGIUNTA DI UN NUOVO PASSO
            case 1: 
                    $località=$_POST["località"];
                    $ncivi=$_POST["n_civico"];
                    $categoria=$_POST["categoria"];
                    $mt=$_POST["metri_quadrati"];
                    $valido=date("m")."/".(date("Y")+1);
                    if($categoria==1){
                        $cauzione=29.20*$mt;
                    }else{
                        $cauzione=17.52*$mt;
                    }
                    $user=$_SESSION["user"];
                    $citt="SELECT username FROM cittadino WHERE username='$user'";
                    $row=mysql_fetch_array(mysql_query($citt));
                    $nome=$row["username"];
                    $newpass="INSERT INTO passi_carrai"
                            ."(proprietario,località_passo,n_civico,categoria,validità,cauzione_annuale,fornitore)"
                            ." VALUES ('$nome','$località','$ncivi','$categoria','$valido','$cauzione',01)";
                    if(mysql_query($newpass)){
                        echo 'La sua richiesta è stata inoltrata ai nostri sistemi.<br>'
                            .'Verrà contattato il prima possibile<br>';
                    }else{
                        die('Abbiamo riscontrato un problema, la preghiamo di contattare il supporto.<br>');
                    }
                    break;
//EFFETTUO LA RIMOZIONE DI UN PASSO ESISTENTE
            case 2: 
                    if(!isset($_POST["passi"])){
                        echo 'Nessun cartello selezionato!';
                    }else{
                        $elimina="DELETE FROM passi_carrai WHERE passo_n='".$_POST["passi"]."'";
                        if(mysql_query($elimina)){
                            echo'La richiesta di eliminazione è stata inviata,<br>verrà contattato il prima possibile<br>';
                        }else {
                            die('Abbiamo riscontrato un problema, la preghiamo di contattare il supporto.<br>');
                        }
                        
                    }
                    break;
//EFFETTUO LA CONFERMA DI PAGAMENTO CON SUCCESSIVO PROLUNGAMENTO DEL PERIODO DI VALIDITà DEL PASSO STESSO
            case 3: 
                    if(!isset($_POST["passi"])){
                        echo 'Nessun cartello selezionato!';
                    }else{
                        echo "<form action='Pagamento.php' method='post'>";
                            echo "<input type='hidden' name='passi' value='".$_POST["passi"]."'>";
                            echo "<label>Pagamento Passo carraio n.:</label>"
                                ."<input type='text' name='n_passo' value='".$_POST["passi"]."'disabled><br>";
                            echo "Metodo di pagamento: <select name='carta'>"
                                ."<option value='Visa'>Visa</option>\n"
                                ."<option value='Master Card'>Master Card</option>\n"
                                ."<option value='American Express'>American Express</option>\n"
                                ."<option value='Conto Corrente'>Conto Corrente</option>\n"
                            ."</select><br>";
                            echo "Estremi di pagamento: <input type='text' name='codice_carta'><br>";
                            $cauzione=mysql_query("SELECT cauzione_annuale FROM passi_carrai WHERE passo_n='".$_POST["passi"]."'");
                            $importo=mysql_fetch_array($cauzione);
                            echo "<label>Importo: </label><input type='text' name='importo' value='".$importo["cauzione_annuale"]."' disabled><br>";
                            echo "<input type='submit' name='conferma_dati' value='Conferma dati'>";
                        echo "</form>";
                        break;
                    }
        }
    }
    include 'Tasto Home.php';
?>
