<?php require 'intestazione.html'; include 'ConnessioneDB.php';?>
    <?php
        $selectPasso="SELECT validità FROM passi_carrai WHERE passo_n='".$_POST["passi"]."'";
        mysql_select_db($dbname1);
        $is=mysql_query($selectPasso);
        while($ris=mysql_fetch_array($is)){
            $split=explode("/", $ris["validità"]);
        }
        if($split[1]>date("Y")){
            echo 'Non è possibile effettuare il pagamento per cartelli non ancora scaduti';
        }else{        
            $intyear=(int)$split[1]+1;
            $newyear=$split[0]."/".(string)$intyear;
            $pagamento="UPDATE passi_carrai SET validità='".$newyear."' WHERE passo_n='".$_POST["passi"]."'";
            if(mysql_query($pagamento)){
                echo '<br>Dati inviati, verrà contattato tramite e-mail per la conferma di avvenuto pagamento<br>';
            }else{
                die("Pagamento non riuscito, si prega di riprovare più tardi<br>");
            }
        }
        include 'Tasto Home.php';
    ?>