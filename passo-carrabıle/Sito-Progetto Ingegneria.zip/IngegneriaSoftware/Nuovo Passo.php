<?php require 'intestazione.html'?>
<form action="Invio richiesta.php" method="post">
    <label>Nuovo passo: </label><br>
    <label>Località: </label><input type="text" name="località">
    <label>N. civico: </label><input type="text" name="n_civico"><br>
    <label>Il cartello dovra ricoprire un'area di: </label><input type="text" name="metri_quadrati"><label>metri quadrati</label><br><br>
<!--OGNI CATEGORIA HA UN DIVERSO IMPORTO CAUZIONALE-->
    <label>Categoria: </label><select name="categoria">
        <option value="1">1</option>
        <option value="2">2</option>
    </select> <br>1- Centro storico, quartiere, centro urbano <br> 2- Periferia e zone limitrofe<br><br>
    <input type="submit" name="tasto" value="Invio Richiesta">
</form><br>
    <?php include 'Tasto Home.php';?>
